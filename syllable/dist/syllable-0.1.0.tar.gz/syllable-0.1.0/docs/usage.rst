=====
Usage
=====

To use `syllable` in a project::

    from syllable.syllable import sendingWords
    sendingWords('syllable/syllable/Diccionario.txt')


