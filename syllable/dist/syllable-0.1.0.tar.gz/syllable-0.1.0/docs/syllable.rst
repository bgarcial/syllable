syllable package
================

Submodules
----------

syllable.cli module
-------------------

.. automodule:: syllable.cli
    :members:
    :undoc-members:
    :show-inheritance:

syllable.syllable module
------------------------

.. automodule:: syllable.syllable
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: syllable
    :members:
    :undoc-members:
    :show-inheritance:
