========
Syllable
========


.. image:: https://img.shields.io/pypi/v/syllable.svg
        :target: https://pypi.python.org/pypi/syllable

.. image:: https://img.shields.io/travis/bgarcial/syllable.svg
        :target: https://travis-ci.org/bgarcial/syllable

.. image:: https://readthedocs.org/projects/syllable/badge/?version=latest
        :target: https://syllable.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Package that send a word or words set to service and get the syllabes of each phrase sent


* Free software: MIT license
* Documentation: https://syllable.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
