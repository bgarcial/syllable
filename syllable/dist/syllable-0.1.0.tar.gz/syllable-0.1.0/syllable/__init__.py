# -*- coding: utf-8 -*-

"""Top-level package for Syllable."""

__author__ = """Bernardo Augusto Garcia Loaiza"""
__email__ = 'botibagl@gmail.com'
__version__ = '0.1.0'
